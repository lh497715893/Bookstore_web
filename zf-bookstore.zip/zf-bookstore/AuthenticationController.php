<?php

class AuthenticationController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
         $this->db = Zend_Registry::get('db');
       
    }

    public function indexAction()
    {
        // action body
    
    }

    public function signupAction()
    {
        $request = $this->getRequest();
        $form    = new Application_Form_SignupForm();
		
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $member = new Application_Model_Member($form->getValues());
                $mapper  = new Application_Model_MemberMapper();
                $mapper->save($member);
                $_SESSION['data']=$member;
                $this->redirect('/Authentication/login');
                return;
            }
        }

        $this->view->form = $form;
    }

    public function loginAction()
    {
         $db = $this->_getParam('db');
 
        $form = new Application_Form_LoginForm();
 
        if ($form->isValid($_POST)) {
 
            $adapter = new Zend_Auth_Adapter_DbTable(
            
                $db,
                'members',
                'member_login',
                'member_password'
            
                );
 
            $adapter->setIdentity($form->getValue('member_login'));
            $adapter->setCredential($form->getValue('member_password'));
 
            $auth   = Zend_Auth::getInstance();
    
            $result = $auth->authenticate($adapter);
          
 
            if ($result->isValid()) {
            echo"Successful Login";
                $this->_helper->FlashMessenger('Successful Login');
                $this->_redirect('/Authentication/edit');
                return;
            }
            else{
             echo"Failed Login";
            $this->_helper->FlashMessenger('Failed Login');
             $this->_redirect('/Authentication/signup');
             return;
             }
            
 
        }
 
        $this->view->form = $form;
    }

    public function logoutAction()
    {
        // action body
        Zend_Auth::getInstance()->clearIdentity();
    $this->_redirect('/books/view');
    }

    public function editAction()
    {
        // action body
         $request = $this->getRequest();
        $form    = new Application_Form_EditForm();
		
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $member = new Application_Model_Member($form->getValues());
                $mapper  = new Application_Model_MemberMapper();
                $mapper->update($member);
                $this->redirect('/books/view');
                return;
            }
        }

        $this->view->form = $form;
		 
			
    }


}









