<?php

class Application_Model_Member
{
	protected $member_id;
	protected $member_login;
    protected $first_name;
	protected $member_password;
	protected $last_name;
	protected $email;
	protected $birthday;

 	public function __construct(array $options = null)
    {
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }
     public function __set($name, $value)
    {
        $method = 'set' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid member property');
        }
        $this->$method($value);
    }

    public function __get($name)
    {
        $method = 'get' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid menber property');
        }
        return $this->$method();
    }
    public function setOptions(array $options)
    {
        $methods = get_class_methods($this);
        foreach ($options as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (in_array($method, $methods)) {
                $this->$method($value);
            }
        }
        return $this;
    }
    
    public function setId($id)
    {
        $this->member_id = (int) $id;
        return $this;
    }

    public function getId()
    {
        return $this->member_id;
    }
    
    
     public function setLoginId($text)
    {
        $this->member_login = (string) $text;
        return $this;
    }

    public function getLoginId()
    {
        return $this->member_login;
    }
    

	public function setFirstName($text)
    {
        $this->first_name = (string) $text;
        return $this;
    }

    public function getFirstName()
    {
        return $this->first_name;
    }
    
    
    public function setPassword($password)
    {
        $this->member_password = (string) $password;
        return $this;
    }

    public function getPassword()
    {
        return $this->member_password;
    }
    
    
	public function setLastName($text)
    {
        $this->last_name = (string) $text;
        return $this;
    }

    public function getLastName()
    {
        return $this->last_name;
    }
    
    
    public function setEmail($email)
    {
        $this->email = (string) $email;
        return $this;
    }

    public function getEmail()
    {
        return $this->email;
    }
    
    
    public function setBirthday($date)
    {
        $this->birthday = (string) $date;
        return $this;
    }

    public function getBirthday()
    {
        return $this->birthday;
    }
}

