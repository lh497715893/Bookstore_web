<?php

class Application_Form_Registration extends Zend_Form
{	 

	public function __construct($options = null) 
    { 
        parent::__construct($options);
     

        $email = new Zend_Form_Element_Text('Email');
        $email->setLabel('Email address')
              ->addFilter('StringToLower')
              ->setRequired(true)
              ->addValidator('NotEmpty', true)
              ->addValidator('EmailAddress');  
			  
			  
        $birthday = new Zend_Form_Element_Text('birthday');
        $birthday->setLabel('Birthday')
              ->addValidator('date');   
		
        $this->addElements(array($email,$birthday));
        
    } 



    public function init()
    {
        /* Form Elements & Other Definitions Here ... */
		        // Set the method for the display form to POST
        $this->setMethod('post');

        // Add an name element
        $this->addElement('text', 'MemberLogin', array(
            'label'      => 'Login_ID:',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(5, 50))
                )     
        ));
		
		$this->addElement('password', 'MemberPassword', array(
            'label'      => 'Password:',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(5, 5))
				
                )     
        ));
		
		$this->addElement('password', 'confirmedPassword', array(
            'label'      => 'Confirmed password:',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(5, 5))
				
                )     
        ));
		
		$this->addElement('text', 'FirstName', array(
            'label'      => 'First name:',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50))
                )     
        ));
		
		$this->addElement('text', 'LastName', array(
            'label'      => 'Last name:',     
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50))
                )     
        ));
		
		$this->addElement('text', 'Email', array(
            'label'      => 'e_mail:',     
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50)),
                )     
        ));
		

		
		$this->addElement('text', 'birthday', array(
            'label'      => 'Birthday:',     
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50))
                )     
        ));
		
		$this->addElement('submit', 'submit', array(
            'ignore'   => true,
            'label'    => 'Register',
        ));
		
    }


}

