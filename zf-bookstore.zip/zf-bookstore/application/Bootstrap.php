<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{	
	protected function _initDoctype()
    {
        $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->doctype('XHTML1_STRICT');
	
    }
				protected function _initDB()
			{
			       $parameters  = array(
			               'host' => 'localhost',
			               'username' => 'root',
			               'password' =>'',
			               'dbname' =>'bookstore'
			       );
			       try {
			               $db = Zend_Db::factory('Pdo_Mysql', $parameters );
			               $db->getConnection();
			       } catch (Zend_Db_Adapter_Exception $e) {
			               echo $e->getMessage();
			               die('Could not connect to database.');
			       } catch (Zend_Exception $e) {
			               echo $e->getMessage();
			               die('Could not connect to database.');
			       }
			       Zend_Registry::set('db', $db);
			       Zend_Db_Table_Abstract::setDefaultAdapter($db);
			} 

    protected function _initAutoload()
    {
        $moduleLoader = new Zend_Application_Module_Autoloader(array(
            'namespace' => '', 
            'basePath'  => APPLICATION_PATH));
        return $moduleLoader;
        
    }

}

