<?php
class Members extends Zend_Db_Table
{
	protected $_name="members";

}

?>