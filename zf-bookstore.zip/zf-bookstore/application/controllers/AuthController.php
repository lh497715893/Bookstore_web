<?php

class AuthController extends Zend_Controller_Action
{
    public function indexAction()
    {
		/* default to the view action */
		$this->_redirect('/auth/login');
		//$this->_helper->redirector('view');		
	}
	
		public function viewAction()
    {
        $book = new Application_Model_BookMapper();
        $this->view->auth = $book->fetchAll();
    }
	public function loginAction()
    {
        $db = $this->_getParam('db');
 
        $loginForm = new Application_Form_Login();
 
        if ($loginForm->isValid($_POST)) {
 
            $adapter = new Zend_Auth_Adapter_DbTable(
                $db,
                'members',
                'member_login',
                'member_password'

                );

            $adapter->setIdentity($loginForm->getValue('username'));
            $adapter->setCredential($loginForm->getValue('password'));
 
            $auth   = Zend_Auth::getInstance();
            $result = $auth->authenticate($adapter);
 
            if ($result->isValid()) {
                $this->_helper->FlashMessenger('Successful Login');

                $this->_redirect('/auth/edit');
                return;
            }else{
				$this->_helper->FlashMessenger('Successful failed');

                $this->_redirect('../members/Registration');
                return;
			}
 
        }
 
        $this->view->form = $loginForm;
 
    }
	
	public function editAction()
	
    {
        $request = $this->getRequest();
        $form    = new Application_Form_Edit();
		
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $member = new Application_Model_Member($form->getValues());
                $mapper  = new Application_Model_MemberMapper();
                $mapper->update($member);
                return $this->_redirect('auth/view');
            }
        }

        $this->view->form = $form;
		
	}
	
	public function logoutAction()
	
    {
		$this->_redirect('/auth/login');
		
	}
	

}

