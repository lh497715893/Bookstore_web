<?php

class BooksController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
		$this->db = Zend_Registry::get('db');
    }

    public function indexAction()
    {
		/* default to the view action */
		$this->_redirect('/books/view');
		//$this->_helper->redirector('view');		
	}
	
	/* List of all the books */
	public function viewAction()
    {
        $book = new Application_Model_BookMapper();
//		$this->view->books = $book->fetchAll();
		$request = $this->getRequest();
		$search = $request->getParam("search");			
		$filteredSearch = ($search) ? strip_tags(htmlspecialchars($search, ENT_QUOTES)) : 'jquery';
			
			// Local book search
		$sql = "SELECT * FROM `items` where name like '%$filteredSearch%'ORDER BY name ASC";
	if($filteredSearch!=$search){
		$sql = "SELECT * FROM `items`";
	}
		$result = $this->db->fetchAssoc($sql);
		$this->view->assign('search',$search);
		$this->view->assign('datas',$result); 
    }
	
	/* Insert a new book */
    public function insertAction()
    {
        $request = $this->getRequest();
        $form    = new Application_Form_Book();
		
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $book = new Application_Model_Book($form->getValues());
                $mapper  = new Application_Model_BookMapper();
                $mapper->save($book);
                return $this->_helper->redirector('view');
            }
        }

        $this->view->form = $form;
    }

	/* Update the book record */
	public function editAction()
    {
        $request = $this->getRequest();
		$id = $request->getParam("id");

        $form    = new Application_Form_Book();

        $book    = new Application_Model_Book();
		$mapper  = new Application_Model_BookMapper();
        $mapper->find($id, $book);
//		$this->view->book = $book;
		
		$form->populate($book);
		
		$this->view->form=$form;

    }	
	public function detailAction()
    {
        $request = $this->getRequest();
		$id = $request->getParam("id");
        
        $book    = new Application_Model_Book();
		$mapper  = new Application_Model_BookMapper();
        $mapper->find($id, $book);
		$this->view->book = $book;
		
    }

}
