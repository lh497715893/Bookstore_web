<?php

class MembersController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        // action body
		$this->_redirect('/members/registration');
    }
	
	public function viewAction()
    {
        $member = new Application_Model_MemberMapper();
        $this->view->members = $member->fetchAll();
    }

    public function registrationAction()
    {
        $request = $this->getRequest();
        $form    = new Application_Form_Registration();
		
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $member = new Application_Model_Member($form->getValues());
                $mapper  = new Application_Model_MemberMapper();
                $mapper->save($member);
                return $this->_redirect('/auth/login');
            }
        }

        $this->view->form = $form;
    }

}

